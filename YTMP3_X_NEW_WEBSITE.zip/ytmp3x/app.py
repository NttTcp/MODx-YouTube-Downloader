import os, re, uuid, tempfile, time
from urllib.parse import urlparse, parse_qs
from flask import Flask, request, jsonify, send_file, send_from_directory
import yt_dlp
BASE_DIR=os.path.dirname(os.path.abspath(__file__)); TEMP_DIR=os.path.join(tempfile.gettempdir(),'ytmp3x'); os.makedirs(TEMP_DIR,exist_ok=True)
app=Flask(__name__,static_folder=None)
def valid(u):
    try:
        if not u.startswith(('http://','https://')): u='https://'+u
        p=urlparse(u); h=p.netloc.lower().split(':')[0]; path=p.path.strip('/')
        if h in ('youtu.be','www.youtu.be'): return bool(path)
        if h in ('youtube.com','www.youtube.com','m.youtube.com','music.youtube.com'):
            if path=='watch': return bool(parse_qs(p.query).get('v',[''])[0])
            return any(path.startswith(x) and len(path.split('/',1)[1].split('/')[0])>0 for x in ('shorts/','embed/','live/'))
    except: pass
    return False
def err(m,c=400): return jsonify(ok=False,error=m),c
def opts(): return {'quiet':True,'no_warnings':True,'noplaylist':True,'socket_timeout':30,'retries':2,'extractor_args':{'youtube':{'player_client':['android','web']}}}
def find(uid,ext):
    for n in os.listdir(TEMP_DIR):
        if n.startswith(uid) and n.endswith('.'+ext): return os.path.join(TEMP_DIR,n)
    return None
@app.get('/')
def home():
    p=os.path.join(BASE_DIR,'index.html')
    return send_from_directory(BASE_DIR,'index.html') if os.path.exists(p) else jsonify(ok=True,service='YTMP3 X')
@app.get('/api/health')
def health(): return jsonify(ok=True,service='ytmp3x',time=int(time.time()))
@app.get('/api/<kind>')
def convert(kind):
    if kind not in ('mp3','mp4'): return err('Unknown endpoint',404)
    url=request.args.get('url','').strip(); quality=request.args.get('quality','192' if kind=='mp3' else 'best').lower()
    if not valid(url): return err('Invalid YouTube URL.')
    uid=uuid.uuid4().hex; out=os.path.join(TEMP_DIR,uid+'.%(ext)s'); o=opts();
    if kind=='mp3':
        if quality not in ('128','192','256','320'): quality='192'
        o.update(format='bestaudio/best',outtmpl=out,postprocessors=[{'key':'FFmpegExtractAudio','preferredcodec':'mp3','preferredquality':quality}],prefer_ffmpeg=True)
    else:
        h=quality if quality in ('2160','1440','1080','720','480','360') else None
        fmt=(f'bestvideo[height<={h}][ext=mp4]+bestaudio[ext=m4a]/best[height<={h}]' if h else 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best')
        o.update(format=fmt,outtmpl=out,merge_output_format='mp4',prefer_ffmpeg=True)
    try:
        with yt_dlp.YoutubeDL(o) as y: info=y.extract_info(url,download=True)
        path=find(uid,kind)
        if not path: return err('Conversion failed. FFmpeg may be unavailable on the server.',500)
        return jsonify(ok=True,title=info.get('title','download'),download_url='/api/download/'+os.path.basename(path))
    except Exception as e: return err(str(e)[:400],500)
@app.get('/api/download/<name>')
def download(name):
    if not re.fullmatch(r'[a-f0-9]{32}\.(mp3|mp4)',name): return err('Not found',404)
    p=os.path.join(TEMP_DIR,name)
    if not os.path.isfile(p): return err('File expired or not found',404)
    return send_file(p,as_attachment=True,download_name=name)
